docker build -t gorank:1.0 .

