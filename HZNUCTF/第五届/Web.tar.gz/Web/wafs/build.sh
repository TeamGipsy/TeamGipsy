docker build -t wafs:1.0 .
