use mysql;
SET PASSWORD FOR 'root'@'localhost' = PASSWORD('asd222!!@332asc');
flush privileges;