#!/bin/sh
echo $FLAG > /flag
chmod 644 /flag