<?php
$FLAG=readfile("/flag");
